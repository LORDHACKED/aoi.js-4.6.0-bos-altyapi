Lütfen package.json klasöründe bulunan aoi.js sürümünü en son sürüme güncellemeyin. Nedeni ise yeni sürümde node versiyonu değişmiştir ve aoi.js versiyonu güncellenirse bot çalışmayacaktır.
