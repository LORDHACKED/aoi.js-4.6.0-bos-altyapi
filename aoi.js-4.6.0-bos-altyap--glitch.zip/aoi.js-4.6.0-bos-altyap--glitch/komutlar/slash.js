module.exports = {
  name: "slash",
  code: `
$createSlashCommand[$guildID;version;Return's Aoi.js's current version]
`
}