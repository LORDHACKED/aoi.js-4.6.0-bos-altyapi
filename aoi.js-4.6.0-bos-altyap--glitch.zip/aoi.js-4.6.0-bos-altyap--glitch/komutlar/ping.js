module.exports = {
  name: "ping",
  code: `
  Pong! $ping ms pingim var.
  `
}